# 편한손 창업 모집 (pyeonhanson.co.kr/partners)

초보·주말 부업·은퇴 준비·여성·주부·줄눈/탄성 시공자를 대상으로 한 편한손 창업 지원자 모집 페이지.

## 구성
| 경로 | 설명 |
|---|---|
| `partners/index.html` | 모집 페이지 (원페이지) |
| `partners/apply.php` | 지원서 접수 → MySQL 저장, 선택적 메일 알림 |
| `partners/admin.php` | 지원자 관리 (상태·메모·삭제) |
| `partners/install.php` | 테이블 생성 (최초 1회 실행 후 삭제) |
| `partners/config.sample.php` | 설정 예시 → 서버에서 `config.php`로 복사해 DB 정보 입력 |
| `main-site/index.php` | 메인화면: 히어로 아래 창업 모집 배너 추가 |
| `main-site/includes/header.php` | 상단 메뉴에 "창업 모집" 버튼 추가 |

## 서버 환경
PHP 5.3 이상 / MySQL 5.1 이상 / UTF-8. FTP 업로드 방식.

## 배포
1. `partners/config.sample.php`를 `config.php`로 복사하고 DB 정보·관리자 비밀번호 입력
2. `partners/` 폴더를 웹 루트에 FTP 업로드
3. `/partners/install.php` 1회 실행 후 삭제
4. `main-site/` 파일은 기존 사이트의 같은 위치에 덮어쓰기

`config.php`는 `.gitignore`로 제외되어 있으니 비밀번호가 GitHub에 올라가지 않습니다.
