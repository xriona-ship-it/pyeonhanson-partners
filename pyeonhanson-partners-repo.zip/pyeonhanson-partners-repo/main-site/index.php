<?php
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

$activeCategory = isset($_GET['cat']) ? $_GET['cat'] : 'all';
$validCats = array_keys($GLOBALS['CATEGORIES']);
if ($activeCategory !== 'all' && !in_array($activeCategory, $validCats)) {
    $activeCategory = 'all';
}

$regionOptions = quote_region_options(); // 진주/사천/창원/통영/거제/부산/순천/기타 (기존 견적 지역 목록 재사용)
$activeRegion = isset($_GET['region']) ? $_GET['region'] : 'all';
if ($activeRegion !== 'all' && !in_array($activeRegion, $regionOptions)) {
    $activeRegion = 'all';
}

$perPage = 12;
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage < 1) { $currentPage = 1; }

$filterCategory = $activeCategory === 'all' ? null : $activeCategory;
$filterRegion = $activeRegion === 'all' ? null : $activeRegion;
$totalPostCount = get_posts_count($mysqli, $filterCategory, $filterRegion);
$totalPages = max(1, (int)ceil($totalPostCount / $perPage));
if ($currentPage > $totalPages) { $currentPage = $totalPages; }
$offset = ($currentPage - 1) * $perPage;

$posts = get_posts($mysqli, $filterCategory, $perPage, null, $offset, 'recent', $filterRegion);
record_site_visit($mysqli);

$hangerCode = category_code_by_label('시스템행거');
$shelfCode = category_code_by_label('팬트리선반');
$hangerCover = $hangerCode ? get_category_cover_post($mysqli, $hangerCode) : null;
$shelfCover = $shelfCode ? get_category_cover_post($mysqli, $shelfCode) : null;

$page_title = SITE_NAME . ' | ' . SITE_TAGLINE;
$page_description = '진주·사천·창원·부산·순천 시스템행거·팬트리선반 전문 시공. 시공할 공간 사진 한 장이면 편한손이 직접 확인하고 견적을 안내해드립니다.';
$canonical_url = SITE_URL . '/';
require 'includes/header.php';
?>

<!-- ========== SECTION 1: HERO ========== -->
<section class="hero">
  <div class="wrap">
    <p class="hero-eyebrow">생활에 도움을 드리는 편한손</p>
    <h1 class="hero-title">사진 한 장이면<br>됩니다.</h1>
    <p class="hero-sub">시스템행거 · 팬트리선반 전문 시공</p>
    <p class="hero-desc">안방 드레스룸부터 팬트리, 다용도실까지<br>시공할 공간 사진을 보내주세요.<br><strong>편한손이 직접 확인하고 공간에 맞는 시공방법과 견적을 안내해드립니다.</strong></p>
    <p class="hero-region">진주 · 경남 · 부산 · 순천</p>

    <a class="hero-cta" href="<?php echo SITE_URL; ?>/estimate.php">📸 사진 한 장으로 30초 견적</a>

    <div class="hero-sub-cta">
      <a href="tel:<?php echo SITE_PHONE; ?>">📞 바로 상담하기 <?php echo SITE_PHONE; ?></a>
      <a href="<?php echo SITE_NAVER_BOOKING; ?>" target="_blank" rel="noopener">💬 사진 없이 간단 상담</a>
    </div>

    <p class="hero-note">복잡한 자동견적은 하지 않습니다.<br>사진을 보내주시면 편한손이 직접 확인합니다.</p>
  </div>
</section>

<!-- ========== 편한손 창업 모집 배너 (/partners/) ========== -->
<style>
.pp-banner{max-width:1100px;margin:24px auto 40px;padding:0 16px;box-sizing:border-box}
.pp-banner a{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;background:#121A2C;color:#fff;border-radius:16px;padding:28px;text-decoration:none;box-sizing:border-box}
.pp-banner .pp-tag{display:inline-block;background:#FFC629;color:#121A2C;font-size:13px;font-weight:700;padding:3px 10px;border-radius:4px}
.pp-banner .pp-title{display:block;font-size:26px;font-weight:800;line-height:1.3;margin-top:10px;word-break:keep-all;color:#fff}
.pp-banner .pp-title b{color:#FFC629}
.pp-banner .pp-sub{display:block;font-size:15px;opacity:.8;margin-top:6px;word-break:keep-all;color:#fff}
.pp-banner .pp-btn{background:#FFC629;color:#121A2C;font-weight:800;font-size:17px;padding:14px 22px;border-radius:10px;white-space:nowrap}
@media (max-width:600px){.pp-banner a{padding:22px}.pp-banner .pp-title{font-size:22px}.pp-banner .pp-btn{width:100%;text-align:center;box-sizing:border-box}}
</style>
<section class="pp-banner">
  <a href="<?php echo SITE_URL; ?>/partners/" target="_blank" rel="noopener">
    <span>
      <span class="pp-tag">주말 부업 · 은퇴 준비 · 전업 · 초보 환영</span>
      <span class="pp-title">일당 말고, <b>시간</b>으로 버세요</span>
      <span class="pp-sub">편한손이 45가지 입주 시공을 처음부터 가르쳐 드립니다</span>
    </span>
    <span class="pp-btn">편한손 창업 알아보기 &rarr;</span>
  </a>
</section>

<!-- ========== SECTION 2: 핵심 서비스 (시스템행거 / 팬트리선반) ========== -->
<section class="core-services">
  <div class="wrap">
    <h2 class="section-title">편한손이 가장 많이 하는 시공</h2>
    <div class="core-service-grid">

      <a class="core-service-card" href="?cat=<?php echo h($hangerCode); ?>">
        <?php if ($hangerCover && $hangerCover['cover_thumb'] !== ''): ?>
          <img loading="lazy" src="<?php echo h(uploaded_image_url($hangerCover['cover_thumb'])); ?>" alt="시스템행거 시공 - <?php echo h(SITE_NAME); ?>">
        <?php else: ?>
          <div class="photo-placeholder"></div>
        <?php endif; ?>
        <div class="core-service-body">
          <h3>시스템행거</h3>
          <p>안방 드레스룸부터 작은방까지<br>공간에 맞춰 구성합니다.</p>
          <p class="core-service-tag">일자 · ㄱ자 · ㄷ자 · ㅁ자 · E자</p>
          <span class="core-service-link">실제 시공사례 보기 &rarr;</span>
        </div>
      </a>

      <a class="core-service-card" href="?cat=<?php echo h($shelfCode); ?>">
        <?php if ($shelfCover && $shelfCover['cover_thumb'] !== ''): ?>
          <img loading="lazy" src="<?php echo h(uploaded_image_url($shelfCover['cover_thumb'])); ?>" alt="팬트리선반 시공 - <?php echo h(SITE_NAME); ?>">
        <?php else: ?>
          <div class="photo-placeholder"></div>
        <?php endif; ?>
        <div class="core-service-body">
          <h3>팬트리선반</h3>
          <p>팬트리 · 다용도실 · 알파룸 · 창고<br>필요한 공간에 맞춰 깔끔하게 구성합니다.</p>
          <span class="core-service-link">실제 시공사례 보기 &rarr;</span>
        </div>
      </a>

    </div>
  </div>
</section>

<!-- ========== SECTION 3: 30초 견적 전환 영역 ========== -->
<section class="estimate-promo">
  <div class="wrap">
    <p class="estimate-promo-eyebrow">견적이 어렵게 느껴지셨나요?</p>
    <h2 class="estimate-promo-title">사진 한 장이면 됩니다.</h2>
    <p class="estimate-promo-desc">가로·세로 치수를 몰라도 괜찮습니다.<br>시공할 공간 사진을 보내주세요.<br><strong>편한손이 직접 사진을 확인하고 가능한 시공방법과 견적을 안내해드립니다.</strong></p>

    <div class="estimate-promo-steps">
      <div class="estimate-promo-step"><span>01</span>사진 찍기</div>
      <div class="estimate-promo-arrow">&rarr;</div>
      <div class="estimate-promo-step"><span>02</span>사진 + 연락처 보내기</div>
      <div class="estimate-promo-arrow">&rarr;</div>
      <div class="estimate-promo-step"><span>03</span>편한손이 직접 확인</div>
      <div class="estimate-promo-arrow">&rarr;</div>
      <div class="estimate-promo-step"><span>04</span>전화 상담 &amp; 견적 안내</div>
    </div>

    <a class="hero-cta" href="<?php echo SITE_URL; ?>/estimate.php">📸 30초 견적받기</a>
  </div>
</section>

<!-- ========== SECTION 4: 실제 시공사례 ========== -->
<section id="gallery" class="gallery-section">
  <div class="wrap">
    <h2 class="section-title">실제 시공현장을 확인해보세요.</h2>
  </div>

  <div class="filter-bar">
    <div class="wrap filter-scroll">
      <a href="?<?php echo h(http_build_query(array_filter(array('region' => $activeRegion !== 'all' ? $activeRegion : null)))); ?>#gallery" class="filter-chip<?php echo $activeCategory === 'all' ? ' is-active' : ''; ?>">전체</a>
      <?php foreach (categories_by_priority() as $code => $label): ?>
        <?php $q = array_filter(array('cat' => $code, 'region' => $activeRegion !== 'all' ? $activeRegion : null)); ?>
        <a href="?<?php echo h(http_build_query($q)); ?>#gallery" class="filter-chip<?php echo $activeCategory === $code ? ' is-active' : ''; ?>"><?php echo h($label); ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <main class="wrap gallery-wrap">
    <?php if ($activeRegion !== 'all'): ?>
      <p class="gallery-active-filter"><?php echo h($activeRegion); ?> 지역 시공사례 <a href="?<?php echo $filterCategory ? h('cat=' . $filterCategory) : ''; ?>#gallery" class="gallery-filter-clear">지역 필터 해제 ✕</a></p>
    <?php endif; ?>

    <?php if (empty($posts)): ?>
      <div class="empty-state">
        <p>아직 등록된 시공 사례가 없습니다.</p>
        <p class="empty-sub">다른 카테고리나 지역을 선택해보세요.</p>
      </div>
    <?php else: ?>
      <div class="gallery-grid">
        <?php foreach ($posts as $p): ?>
          <a class="photo-card" href="work.php?id=<?php echo (int)$p['id']; ?>">
            <span class="tag-sticker"><?php echo h(category_label($p['category'])); ?></span>
            <?php if ($p['photo_count'] > 1): ?><span class="count-badge"><?php echo (int)$p['photo_count']; ?>장</span><?php endif; ?>
            <?php if ($p['cover_thumb'] !== ''): ?>
              <img loading="lazy" src="<?php echo h(uploaded_image_url($p['cover_thumb'])); ?>" alt="<?php echo h($p['title'] . ' - ' . SITE_NAME); ?>">
            <?php else: ?>
              <div class="photo-placeholder"></div>
            <?php endif; ?>
            <span class="card-caption">
              <strong><?php echo h($p['title']); ?></strong>
              <?php if ($p['region'] !== ''): ?><em><?php echo h($p['region']); ?></em><?php endif; ?>
            </span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($totalPages > 1): ?>
      <nav class="pagination">
        <?php if ($currentPage > 1): ?>
          <a class="page-link" href="<?php echo h(pagination_url($currentPage - 1, $activeCategory, $activeRegion)); ?>#gallery">&larr; 이전</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <?php if ($i === 1 || $i === $totalPages || abs($i - $currentPage) <= 2): ?>
            <a class="page-link<?php echo ($i === $currentPage) ? ' is-active' : ''; ?>" href="<?php echo h(pagination_url($i, $activeCategory, $activeRegion)); ?>#gallery"><?php echo $i; ?></a>
          <?php elseif ($i === $currentPage - 3 || $i === $currentPage + 3): ?>
            <span class="page-ellipsis">…</span>
          <?php endif; ?>
        <?php endfor; ?>

        <?php if ($currentPage < $totalPages): ?>
          <a class="page-link" href="<?php echo h(pagination_url($currentPage + 1, $activeCategory, $activeRegion)); ?>#gallery">다음 &rarr;</a>
        <?php endif; ?>
      </nav>
    <?php endif; ?>
  </main>
</section>

<!-- ========== SECTION 5: 편한손의 차별점 ========== -->
<section class="why-us">
  <div class="wrap">
    <h2 class="section-title">편한손은 직접 보고 판단합니다.</h2>
    <div class="why-us-grid">
      <div class="why-us-item">
        <h3>① 사진으로 먼저 상담</h3>
        <p>복잡한 치수 입력 없이<br>사진으로 먼저 공간을 확인합니다.</p>
      </div>
      <div class="why-us-item">
        <h3>② 공간에 맞춰 제안</h3>
        <p>무조건 많은 것을 넣기보다<br>필요한 만큼 깔끔하게 구성합니다.</p>
      </div>
      <div class="why-us-item">
        <h3>③ 직접 시공</h3>
        <p>상담한 공간을 실제 현장에서 확인하고<br>시공까지 연결합니다.</p>
      </div>
      <div class="why-us-item">
        <h3>④ 현장 대응</h3>
        <p>현장 상황에 따라 필요한 부분을 직접 판단하고<br>시공방법을 조정합니다.</p>
      </div>
    </div>
  </div>
</section>

<!-- ========== SECTION 6: 지역별 시공사례 ========== -->
<section class="region-section">
  <div class="wrap">
    <h2 class="section-title">우리 동네에서도 시공했나요?</h2>
    <div class="region-chip-grid">
      <?php foreach ($regionOptions as $r): ?>
        <?php if ($r === '기타') { continue; } ?>
        <a href="?region=<?php echo h(urlencode($r)); ?>#gallery" class="region-chip<?php echo ($activeRegion === $r) ? ' is-active' : ''; ?>"><?php echo h($r); ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ========== SECTION 7: 마지막 문의 영역 ========== -->
<section class="final-cta">
  <div class="wrap">
    <h2 class="section-title">궁금한 게 있다면 편하게 물어보세요.</h2>
    <div class="final-cta-grid">
      <a class="final-cta-item is-primary" href="<?php echo SITE_URL; ?>/estimate.php">
        <span class="final-cta-icon">📸</span>
        <strong>30초 견적</strong>
        <span>사진이 있다면</span>
      </a>
      <a class="final-cta-item" href="<?php echo SITE_NAVER_BOOKING; ?>" target="_blank" rel="noopener">
        <span class="final-cta-icon">💬</span>
        <strong>간단 상담</strong>
        <span>사진이 없다면</span>
      </a>
      <a class="final-cta-item" href="tel:<?php echo SITE_PHONE; ?>">
        <span class="final-cta-icon">📞</span>
        <strong><?php echo SITE_PHONE; ?></strong>
        <span>바로 이야기하고 싶다면</span>
      </a>
    </div>
  </div>
</section>

<?php $todayCount = get_today_visit_count($mysqli); ?>
<div style="position:fixed;right:12px;bottom:66px;z-index:9999;color:#9CA3A0;font-family:'IBM Plex Mono',monospace;font-size:13px;font-weight:600;user-select:none;">
  <?php echo $todayCount; ?>
</div>

<!-- ========== 모바일 하단 고정 CTA 바 ========== -->
<nav class="mobile-bar">
  <a href="tel:<?php echo SITE_PHONE; ?>" class="mobile-bar-item">
    <span class="mobile-bar-icon">📞</span>전화
  </a>
  <a href="<?php echo SITE_NAVER_BOOKING; ?>" target="_blank" rel="noopener" class="mobile-bar-item">
    <span class="mobile-bar-icon">💬</span>간단상담
  </a>
  <a href="<?php echo SITE_URL; ?>/estimate.php" class="mobile-bar-item is-primary">
    <span class="mobile-bar-icon">📸</span>30초 견적
  </a>
</nav>

<?php require 'includes/footer.php'; ?>
