<?php
// 사용: 각 public 페이지에서 $page_title, $page_description, $canonical_url (선택) 을 지정한 뒤 include
if (!isset($page_title)) { $page_title = SITE_NAME . ' | ' . SITE_TAGLINE; }
if (!isset($page_description)) { $page_description = SITE_TAGLINE . '. 시스템행거, 팬트리선반, 환풍기·조명·블라인드·도어락 시공 사진을 확인하세요.'; }
if (!isset($canonical_url)) { $canonical_url = SITE_URL . $_SERVER['REQUEST_URI']; }
if (!isset($og_image)) { $og_image = SITE_URL . '/assets/img/og-default.jpg'; }
?><!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($page_title); ?></title>
<meta name="description" content="<?php echo h($page_description); ?>">
<link rel="canonical" href="<?php echo h($canonical_url); ?>">

<!-- Open Graph / 카카오톡·네이버 공유 미리보기 -->
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo h(SITE_NAME); ?>">
<meta property="og:title" content="<?php echo h($page_title); ?>">
<meta property="og:description" content="<?php echo h($page_description); ?>">
<meta property="og:url" content="<?php echo h($canonical_url); ?>">
<meta property="og:image" content="<?php echo h($og_image); ?>">
<meta name="naver-site-verification" content="여기에_네이버서치어드바이저_인증코드">
<meta name="google-site-verification" content="여기에_구글서치콘솔_인증코드">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=IBM+Plex+Mono:wght@500&family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css?v=<?php echo @filemtime(dirname(__FILE__) . '/../assets/css/style.css'); ?>">

<!-- JSON-LD: 지역 사업체 정보 (구글/네이버 지식패널·AI탭 노출용) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "<?php echo SITE_NAME; ?>",
  "description": "<?php echo SITE_TAGLINE; ?>",
  "url": "<?php echo SITE_URL; ?>",
  "telephone": "<?php echo SITE_PHONE; ?>",
  "areaServed": ["진주시", "사천시", "삼천포", "순천시"],
  "address": {
    "@type": "PostalAddress",
    "addressRegion": "<?php echo SITE_REGION; ?>",
    "addressCountry": "KR"
  }
}
</script>
</head>
<body>
<header class="site-header">
  <div class="wrap header-inner">
    <a href="<?php echo SITE_URL; ?>/" class="brand">
      <span class="brand-mark">편한손</span>
      <span class="brand-sub">PYEONHANSON</span>
    </a>
    <nav class="main-nav">
      <a href="<?php echo SITE_URL; ?>/">시공 사진</a>
      <a href="<?php echo SITE_URL; ?>/estimate.php" class="nav-quote">📸 30초 견적</a>
      <a href="<?php echo SITE_NAVER_BOOKING; ?>" target="_blank" rel="noopener">💬 간단 상담</a>
      <a href="<?php echo SITE_URL; ?>/partners/" target="_blank" rel="noopener" class="nav-partners" style="background:#FFC629;color:#121A2C;font-weight:700;padding:4px 10px;border-radius:6px;white-space:nowrap;text-decoration:none">🛠 창업 모집</a>
      <a href="tel:<?php echo SITE_PHONE; ?>" class="nav-phone"><?php echo SITE_PHONE; ?></a>
    </nav>
  </div>
</header>
